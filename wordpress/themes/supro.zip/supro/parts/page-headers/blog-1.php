<div class="page-header blog-page-header layout-1 text-center">
	<div class="container">
		<?php
		supro_blog_description();
		the_archive_title( '<h1>', '</h1>' );
		?>
	</div>
</div>