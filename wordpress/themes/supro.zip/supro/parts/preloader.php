<div id="preloader" class="preloader">
	<span class="loading-icon">
		<span class="bubble"><span class="dot"></span></span>
		<span class="bubble"><span class="dot"></span></span>
		<span class="bubble"><span class="dot"></span></span>
	</span>
</div>