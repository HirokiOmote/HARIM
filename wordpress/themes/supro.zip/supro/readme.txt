Supro - Minimalist AJAX WooCommerce WordPress Theme
------------------------------

Supro is a a clean & minimal AJAX WooCommerce WordPress Theme for shopping online stores. This theme is suited for a lot of e-commerce website such as fashion store, furniture store, decoration store, etc.

Change log:

Version 1.0.2:

- New: Support RTL.
- New: Add new Home Shoppable Images.
- Fix: Responsive Menu.

Version 1.0.1:

- Fix: Responsive for the Custom Heading

Version 1.0
- Initial





