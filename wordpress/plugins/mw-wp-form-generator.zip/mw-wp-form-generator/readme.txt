=== MW WP Form Generator ===
Contributors: inc2734
Donate link: http://www.amazon.co.jp/registry/wishlist/39ANKRNSTNW40
Tags: plugin, form, gui, contact
Requires at least: 4.0.0
Tested up to: 4.7.2
Stable tag: 1.6.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Premium add-on of MW WP Form. This plugin add form generator gui in form creating page of MW WP Form. This plugin needs MW WP Form version 2.6.1 or later.

== Description ==

Premium add-on of MW WP Form. This plugin add form generator gui in form creating page of MW WP Form.
This plugin needs MW WP Form version 2.1.0 or later.
IF you add style add-on, you can change to your favorite form design.
MW WP Form generator has three of style from the beginning.

== Installation ==

1. Upload to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.6.0 =
* Update g-standard design.
* Update g-naked design.
* Update g-enquete design.

= 1.5.2 =
* Fixed a bug that require mark isn't display when set the required validation.

= 1.5.1 =
* Fixed some form fields style.

= 1.5.0 =
* Added form field description setting.

= 1.4.0 =
* Fixed a bug that displayed notice error when there are no form fields.
* This plugin needs MW WP Form version 2.6.1 or later.

= 1.3.0 =
* Fixed a bug that removed option when using double quotation in option value.
* Update templates styles.

= 1.2.0 =
* Fixed a updater bug.

= 1.1.0 =
* This plugin needs MW WP Form version 2.4.0 or later.

= 1.0.2 =
* Fixed a bug that the width of g-standar to overflow when displayed smartphone.

= 1.0.1 =
* Fix some css bugs.

= 1.0.0 =
* Initial release.
